package Controller;

import Main.Menu;
import Model.Connector;

public class ControllerTampilan {
    private Menu menu;
    private Connector connect;
    
    public void showTampilPage(Connector connect){
        if(!connect.checkLogin()){
            return;
        }
        this.connect = connect;
        
        menu.setLocationRelativeTo(null); // Set lokasi relatif
        menu.setVisible(true); // Tampilkan tampilan Menu
    }
}
